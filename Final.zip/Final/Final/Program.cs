﻿using System;
using System.Collections.Generic;
using System.Linq;
namespace Final
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            // Display welcome message and ask user to choose options
            Console.WriteLine("Welcome to Target! Choose the following options: ");
            Console.WriteLine("\t1) Make a Purchase");
            Console.WriteLine("\t2) Make a Return");
            Console.WriteLine("\t3) Manage Inventory");
            Console.WriteLine("\t4) View Report");

            // Read user input
            string userinput = Console.ReadLine();
            int UI = Convert.ToInt32(userinput);

            // Putting items and price in arrays
            string[] items = { "Lego Star Wars", "Cookie" };
            int[] price = { 25, 5 };

            string yesNo;
            string returnitem;

            int final = 0;

            List<int> total = new List<int>();

            // Choice 1
            if (UI == 1)
            {
                do
                {
                    // Display options
                    Console.WriteLine("Which product would you like to purchase?");
                    Console.WriteLine("Item Name \t Price");
                    Console.WriteLine(items[0] + "\t $" + price[0]);
                    Console.WriteLine(items[1] + "\t\t $" + price[1]);

                    // Ask user for items
                    Console.WriteLine("Which items would you like to buy?");
                    returnitem = Console.ReadLine();

                    // Ask if user wants to do it again
                    Console.WriteLine("Anything else? (Y/N): ");
                    yesNo = Console.ReadLine();
                }
                while (yesNo != "N" && yesNo != "n");
                
                for (int i = 0; i < 1; i++)
                {
                    
                    if (returnitem == items[0])
                    {
                        total.Add(Convert.ToInt32(price[0]));
                    }

                    else
                    {
                        total.Add(Convert.ToInt32(price[1]));
                    }

                    for (int j = 0; j< total.Count(); j++)
                    {
                        final += total[j];
                    }

                    // Display total
                    Console.WriteLine("Your Total is: $" + final);
                    Console.WriteLine("Thank you for shopping at Target");
                }
            }

            // Choice 2
            else if (UI == 2)
            {
                do
                {
                    // Display options
                    Console.WriteLine("Which product would you like to return?");
                    Console.WriteLine("Item Name \t Price");
                    Console.WriteLine(items[0] + "\t $" + price[0]);
                    Console.WriteLine(items[1] + "\t\t $" + price[1]);

                    // Ask user which items to return
                    Console.WriteLine("Which items would you like to return?");
                    returnitem = Console.ReadLine();

                    // Ask if user wants to do it again
                    Console.WriteLine("Anything else? (Y/N): ");
                    yesNo = Console.ReadLine();
                }
                while (yesNo != "N" && yesNo != "n");
                for (int i = 0; i < 1; i++)
                {

                    if (returnitem == items[0])
                    {
                        total.Add(Convert.ToInt32(price[0]));
                    }

                    else
                    {
                        total.Add(Convert.ToInt32(price[1]));
                    }

                    for (int j = 0; j < total.Count(); j++)
                    {
                        final += total[j];
                    }

                    // Display total returned
                    Console.WriteLine("Your Refund total is: $" + final);
                    Console.WriteLine("Thank you for shopping at Target");
                }
            }

            // Choice 3
            else if (UI == 3)
            {
                string choice;
                do
                {
                    // Display options
                    Console.WriteLine("The following items are currently in the system: ");
                    Console.WriteLine("Item Name \t Price");
                    Console.WriteLine(items[0] + "\t $" + price[0]);
                    Console.WriteLine(items[1] + "\t\t $" + price[1]);
                    Console.WriteLine("\t1) Add New Item");
                    Console.WriteLine("\t2) Remove Item");
                    Console.WriteLine("\t3) Main Menu");
                    choice = Console.ReadLine();
                    if (choice == "1")
                    {
                        // Add item
                        Console.WriteLine("Add Item:");
                        for (int i = 0; i < 1; i++)
                        {
                            Console.WriteLine("Item Name: ");
                            items[i] = Console.ReadLine();
                            Console.WriteLine("Item Price: ");
                            price[i] = Convert.ToInt32(Console.ReadLine());
                        }

                        // Display add message
                        Console.WriteLine("Added Successfully!");
                    }
                    else
                    {
                        // Remove item
                        Console.WriteLine("Remove Item:");
                        for (int i = 0; i < 1; i++)
                        {
                            Console.WriteLine("Item Name: ");
                            items[i] = Console.ReadLine();
                        }

                        // Dispaly remove message
                        Console.WriteLine("Item Removed Successfully!");
                    }
                }
                while (choice != "1" && choice != "2");
            }

            // Choice 4
            else
            {
                Console.WriteLine("Reports:");

                Console.WriteLine("Total Customers: " + total.Count());
                Console.WriteLine("Total Profit: " + final);
                
                Console.WriteLine("Press any key to go back to main menu");
                Console.ReadKey();
            }
        }
    }
}